package hibernate;

import java.util.List;

public class PageModel<Model> {
	public int datacount;
	public List<Model> models;
}
